import android.annotation.TargetApi
import android.os.Build
import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.M3u8Helper
import com.lagradost.nicehttp.Requests
import com.lagradost.nicehttp.Session
import okhttp3.HttpUrl.Companion.toHttpUrl
import org.jsoup.nodes.Element
import java.util.Base64
import org.mozilla.javascript.Context
import org.mozilla.javascript.Scriptable

fun String.runJS(variableName: String): String {
    val rhino = Context.enter()
    rhino.initSafeStandardObjects()
    rhino.optimizationLevel = -1
    val scope: Scriptable = rhino.initSafeStandardObjects()
    val script = this
    val result: String
    try {
        var js = ""
        for (i in script.indices) {
            js += script[i]
        }
        rhino.evaluateString(scope, js, "JavaScript", 1, null)
        result = Context.toString(scope.get(variableName, scope))
    } finally {
        Context.exit()
    }
    return result
}

class EgyBest : MainAPI() {
    override var lang = "ar"
    override var mainUrl = "https://egybest.org"
    override var name = "EgyBest"
    var pssid = ""
    override val usesWebView = false
    override val hasMainPage = true
    override val supportedTypes = setOf(TvType.TvSeries, TvType.Movie, TvType.Anime)

    private fun String.getIntFromText(): Int? {
        return Regex("""\d+""").find(this)?.groupValues?.firstOrNull()?.toIntOrNull()
    }

    private fun Element.toSearchResponse(): SearchResponse? {
        val url = this.attr("href") ?: return null
        val posterUrl = select("img")?.attr("src")
        var title = select("span.title").text()
        val year = title.getYearFromTitle()
        val isMovie = Regex(".*/movie/.*|.*/masrahiya/.*").matches(url)
        val tvType = if (isMovie) TvType.Movie else TvType.TvSeries
        title = if (year !== null) title else title.split(" (")[0].trim()
        val quality = select("span.ribbon span").text().replace("-", "")
        // If you need to differentiate use the url.
        return MovieSearchResponse(
            title,
            mainUrl + url,
            this@EgyBest.name,
            tvType,
            posterUrl,
            year,
            null,
            quality = getQualityFromString(quality)
        )
    }

    override val mainPage = mainPageOf(
        "$mainUrl/trending/?page=" to "الأفلام الأكثر مشاهدة",
        "$mainUrl/movies/?page=" to "أفلام جديدة",
        "$mainUrl/tv/?page=" to "مسلسلات جديدة ",
        "$mainUrl/tv/korean?page=" to "الدراما الكورية ",
        "$mainUrl/animes/popular?page=" to "مسلسلات الانمي",
        "$mainUrl/wwe/?page=" to "عروض المصارعة ",
        "$mainUrl/movies/latest-bluray-2020-2019?page=" to "أفلام جديدة BluRay",
        "$mainUrl/masrahiyat/?page=" to "مسرحيات ",
        "$mainUrl/movies/latest?page=" to "أحدث الاضافات",
        "$mainUrl/movies/comedy?page=" to "أفلام كوميدية",
        "$mainUrl/explore/?q=superhero/" to "أفلام سوبر هيرو",
        "$mainUrl/movies/animation?page=" to "أفلام انمي و كرتون",
        "$mainUrl/romance?page=" to "أفلام رومانسية",
        "$mainUrl/drama?page=" to "أفلام دراما",
        "$mainUrl/horror?page=" to "أفلام رعب
        